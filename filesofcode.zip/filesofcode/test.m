%% MM 
I = imread('MM_20.bmp');
figure,imshow(I);
pout=rgb2gray(I);
pout_imadjust = imadjust(pout,[0.33 0.37]);

%pout_adapthisteq = adapthisteq(pout_imadjust);
% figure
% subplot(1,2,1)
% imhist(I)
% title('Histogram of Original')
% subplot(1,2,2)
% imhist(pout_adapthisteq)
% title('Histogram of Aqaptive Equalization');
figure,imshow(pout_imadjust)
%pout_histeq = histeq(pout);
%pout_adapthisteq = adapthisteq(pout);
%%
% montage({pout,pout_imadjust,pout_histeq,pout_adapthisteq},'Size',[1 4])
% title("Original Image and Enhanced Images using imadjust, histeq, and adapthisteq")
%%
poutnew=pout.*pout_imadjust;
figure,imshow(poutnew)
%%
bw=imbinarize(poutnew);
bwc=imcomplement(bw);
bw_select=bwareafilt(imcomplement(bw),[8000 1000000]);
figure,imshow(bwc)
figure,imshow(bw_select)
%%
bw_select1=bwareafilt(imcomplement(bw),[800 3000]);
figure,imshow(bw_select1)
%%
% f_select=bw_select+bw_select1;
% figure,imshow(f_select)
%%

se = strel('disk',26);
%Perform a morphological close operation on the image.

closeBW = imclose(bw_select,se);
figure,imshow(I.*uint8(closeBW))
%%
[L, num1] = bwlabel(bw_select);
for k1 = 1 : num1
    Blob = ismember(L, k1);
    newww=I.*uint8(Blob);
    figure,imshow(newww)
    k=imresize(newww,[400 400]);
end
%% AML 
I = imread('BAS_0004.tiff');
%I=squeeze(I);
pout=rgb2gray(I(:,:,1:3));
pout_imadjust = imadjust(pout,[0.3 0.5]);
%figure,imshowpair(I(:,:,1:3),pout_imadjust,'montage')
figure,imshow(pout_imadjust)
%%
% pout_adapthisteq = adapthisteq(pout_imadjust);
% figure
% subplot(1,2,1)
% imhist(I(:,:,1:3))
% title('Histogram of Original')
% subplot(1,2,2)
% imhist(pout_adapthisteq)
% title('Histogram of Aqaptive Equalization');
%%
poutnew=pout.*pout_imadjust;
%figure,imshowpair(pout_imadjust,poutnew,'montage')
figure,imshow(poutnew)
%%
bw=imbinarize(poutnew);
bwc=imcomplement(bw);
bw_select=bwareafilt(imcomplement(bw),[100 Inf]);
figure,imshow(bwc)
figure,imshow(bw_select)
newww=I(:,:,1:3).*uint8(bw_select);
%figure,imshowpair(I(:,:,1:3),newww,'montage')
figure,imshow(newww)
%%
% multi = cat(3,I,pout,pout_adapthisteq,poutnew,bw,bw_select,newww);
% montage(multi);
% axis image off
%%
% figure, 
% subplot(2,3,1),imshow(I(:,:,1:3)),set(gca,'xtick',[],'ytick',[])
% subplot(2,3,2),imshow(pout_imadjust),set(gca,'xtick',[],'ytick',[])
% subplot(2,3,3),imshow(poutnew),set(gca,'xtick',[],'ytick',[])
% subplot(2,3,4),imshow(bwc),set(gca,'xtick',[],'ytick',[])
% subplot(2,3,5),imshow(bw_select),set(gca,'xtick',[],'ytick',[])
% subplot(2,3,6),imshow(newww),set(gca,'xtick',[],'ytick',[])
% ha=get(gcf,'children');
% set(ha(1))
% set(ha(2))
% set(ha(3))
% set(ha(4))
% set(ha(5))
% set(ha(6))
%% ALL 

I = imread('ALL_29.bmp');
figure,imshow(I);
pout=rgb2gray(I);
pout_imadjust = imadjust(pout,[0.30 0.41]);
%figure,imshowpair(I,pout_imadjust,'montage')
figure,imshow(pout_imadjust)
%%
poutnew=pout.*pout_imadjust;
figure,imshow(poutnew)
%%
bw=imbinarize(poutnew);
bwc=imcomplement(bw);
bw_select=bwareafilt(imcomplement(bw),[8000 1000000]);
figure,imshow(bwc)
figure,imshow(bw_select)
%%
figure,imshow(I.*uint8(bw_select))
%%  Now CNN1 and CNN2 load
CNN1=load('87.41.mat');
CNN2=load('89.63.mat');
%%
N1=CNN1.net;
N2=CNN2.net;
%%
imageFolder = fullfile('/Users/raheelbaig/OneDrive - Higher Education Commission/Thesis/Results/finalDataset_BloodCancer/','Segmented');

%%
imds = imageDatastore(imageFolder, 'LabelSource', 'foldernames', 'IncludeSubfolders',true);

%%
[trainingSet, testSet] = splitEachLabel(imds, 0.7, 'randomize');
%%
imageSize = [200 200 3];
augmentedTrainingSet = augmentedImageDatastore(imageSize, trainingSet, 'ColorPreprocessing', 'gray2rgb');
augmentedTestSet = augmentedImageDatastore(imageSize, testSet, 'ColorPreprocessing', 'gray2rgb');


%% CNN1 results
for i=1:length(CNN1.YTest)
 if (CNN1.YTest(i)=='ALL')
     YTest_num(i)=0;
 elseif(CNN1.YTest(i)=='AML')
     YTest_num(i)=1;
 elseif(CNN1.YTest(i)=='MM')
     YTest_num(i)=2;
 end   
end
%%
for i=1:length(CNN1.YPred)
 if (CNN1.YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(CNN1.YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(CNN1.YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end  
%%
confusionchart(CNN1.YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("Confusion matrix CNN-1");
%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);
disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa
%% CNN2 results
%%
for i=1:length(CNN2.YTest)
 if (CNN2.YTest(i)=='ALL')
     YTest_num(i)=0;
 elseif(CNN2.YTest(i)=='AML')
     YTest_num(i)=1;
 elseif(CNN2.YTest(i)=='MM')
     YTest_num(i)=2;
 end   
end
%%
for i=1:length(CNN2.YPred)
 if (CNN2.YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(CNN2.YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(CNN2.YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end
%%
confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("Confusion matrix CNN-2");
%%

[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);
disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa
%%
featureLayer = 'fc';
trainingFeatures1 = activations(N1, augmentedTrainingSet, featureLayer);
testingFeatures1=activations(N1, augmentedTestSet, featureLayer);
%%
featureLayer = 'fc';
trainingFeatures2 = activations(N2, augmentedTrainingSet, featureLayer);
testingFeatures2=activations(N2, augmentedTestSet, featureLayer);
%%
trainingFeatures1=squeeze(trainingFeatures1)';
trainingFeatures2=squeeze(trainingFeatures2)';
testingFeatures1=squeeze(testingFeatures1)';
testingFeatures2=squeeze(testingFeatures2)';
%%
[trainZ,testZ] = ccaFuse(trainingFeatures1, trainingFeatures2, testingFeatures1, testingFeatures2, 'conc');

 %% SVM1
 YTest=testSet.Labels;
 svmmL=fitcecoc(trainZ,trainingSet.Labels);

YPred = predict(svmmL,testZ);
accuracy = mean(YPred == YTest)
%%
YPred = predict(svmmL,testZ);
 YTest=testSet.Labels;

 confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("CCA Fusion using SVM");
%%
%%
for i=1:length(YTest)
 if (YTest(i)=='ALL')
     YTest_num(i)=0;
 elseif(YTest(i)=='AML')
     YTest_num(i)=1;
 elseif(YTest(i)=='MM')
     YTest_num(i)=2;
 end   
end
%%
for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end    

%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa

%% 4 knn fine
knnfineL = fitcknn(trainZ,trainingSet.Labels,'NumNeighbors',1,...
    'NSMethod','exhaustive','Distance','minkowski',...
    'Standardize',1);

YPred = predict(knnfineL,testZ);

accuracy = mean(YPred == testSet.Labels)
%%
YPred = predict(knnfineL,testZ);
 YTest=testSet.Labels;

 confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("CCA Fusion using F-KNN");
%%
for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end    
%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa

%% 5 medium knn
knnmediumL = fitcknn(trainZ,trainingSet.Labels,'NumNeighbors',10,...
    'NSMethod','exhaustive','Distance','minkowski',...
    'Standardize',1);

YPred = predict(knnmediumL,testZ);

accuracy = mean(YPred == testSet.Labels)
%%%%
YPred = predict(knnmediumL,testZ);
 YTest=testSet.Labels;

 confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("CCA Fusion using Medium-KNN");
%%
%%
for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end    
%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa

%% 6 coarse knn
knncoarseL = fitcknn(trainZ,trainingSet.Labels,'NumNeighbors',100,...
    'NSMethod','exhaustive','Distance','minkowski',...
    'Standardize',1);
YPred = predict(knncoarseL,testZ);

accuracy = mean(YPred == testSet.Labels)

%%
YPred = predict(knncoarseL,testZ);
 YTest=testSet.Labels;

confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("CCA Fusion using Coarse-KNN");
%%
%%
for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end  
%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa
%% 7
bagmodelL = fitcensemble(trainZ,trainingSet.Labels,'Method','Bag');

YPred = predict(bagmodelL,testZ);

accuracy = mean(YPred == testSet.Labels)
%%
YPred = predict(bagmodelL,testZ);
 YTest=testSet.Labels;
confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("CCA Fusion using Bagging Model");
%%
%%
for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end
%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa
%% 8
totalboostmodelL = fitcensemble(trainZ,trainingSet.Labels,'Method','TotalBoost');

YPred = predict(totalboostmodelL,testZ);

accuracy = mean(YPred == testSet.Labels)
%%
YPred = predict(totalboostmodelL,testZ);
 YTest=testSet.Labels;
confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("CCA Fusion using Total Boost Model");
%%
%%
for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end

%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa


%% 11
LPboostmodelL = fitcensemble(trainZ,trainingSet.Labels,'Method','LPBoost');
YPred = predict(LPboostmodelL,testZ);
accuracy = mean(YPred == testSet.Labels)
%%
YPred = predict(LPboostmodelL,testZ);
 YTest=testSet.Labels;
confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("CCA Fusion using LPBoost Model");


%%
for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end
%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa
%% 12
RUSboostmodelL = fitcensemble(trainZ,trainingSet.Labels,'Method','RUSBoost');
YPred = predict(RUSboostmodelL,testZ);
accuracy = mean(YPred == testSet.Labels)
%%
%%
YPred = predict(RUSboostmodelL,testZ);
 YTest=testSet.Labels;
confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("CCA Fusion using RUSboostmodel");
%%
for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end
%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa

