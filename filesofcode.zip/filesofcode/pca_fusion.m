

%% pca fusion
[coeff,score1,latent]= pca(trainingFeatures1);
[coeff,score2,latent]=pca(trainingFeatures2); 
[coeff,score3,latent] = pca(testingFeatures1);
[coeff,score4,latent]= pca(testingFeatures2);
 %%
 trainingFV=[score1,score2];
 testingFV=[score3,score4];
 
 %% 1
 YTest=testSet.Labels;
 svmmL=fitcecoc(trainingFV,trainingSet.Labels);

YPred = predict(svmmL,testingFV);
accuracy = mean(YPred == YTest)
confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("PCA Fusion using SVM");
%%
for i=1:length(YTest)
 if (YTest(i)=='ALL')
     YTest_num(i)=0;
 elseif(YTest(i)=='AML')
     YTest_num(i)=1;
 elseif(YTest(i)=='MM')
     YTest_num(i)=2;
 end   
end
%%
for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end    

%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa

%% 4 knn fine
knnfineL = fitcknn(trainingFV,trainingSet.Labels,'NumNeighbors',1,...
    'NSMethod','exhaustive','Distance','minkowski',...
    'Standardize',1);

YPred = predict(knnfineL,testingFV);

accuracy = mean(YPred == testSet.Labels)
confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("PCA Fusion using Fine KNN");

%%
for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end    
%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa

%% 5 medium knn
knnmediumL = fitcknn(trainingFV,trainingSet.Labels,'NumNeighbors',10,...
    'NSMethod','exhaustive','Distance','minkowski',...
    'Standardize',1);

YPred = predict(knnmediumL,testingFV);

accuracy = mean(YPred == testSet.Labels)
confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("PCA Fusion using Medium KNN");
%%
%%
for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end    
%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa

%% 6 coarse knn
knncoarseL = fitcknn(trainingFV,trainingSet.Labels,'NumNeighbors',100,...
    'NSMethod','exhaustive','Distance','minkowski',...
    'Standardize',1);
YPred = predict(knncoarseL,testingFV);

accuracy = mean(YPred == testSet.Labels)
confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("PCA Fusion using Coarse KNN");
%%
%%
for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end  
%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa
%% 7
bagmodelL = fitcensemble(trainingFV,trainingSet.Labels,'Method','Bag');

YPred = predict(bagmodelL,testingFV);

accuracy = mean(YPred == testSet.Labels)
confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("PCA Fusion using Bagging Ensembler");

%%
for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end
%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa
%% 8
totalboostmodelL = fitcensemble(trainingFV,trainingSet.Labels,'Method','TotalBoost');

YPred = predict(totalboostmodelL,testingFV);

accuracy = mean(YPred == testSet.Labels)
confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("PCA Fusion using TotalBoost");

%%
for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end

%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa


%% 11
LPboostmodelL = fitcensemble(trainingFV,trainingSet.Labels,'Method','LPBoost');
YPred = predict(LPboostmodelL,testingFV);
accuracy = mean(YPred == testSet.Labels)
confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("PCA Fusion using LPBoost");

%%
for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end
%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa
%% 12
RUSboostmodelL = fitcensemble(trainingFV,trainingSet.Labels,'Method','RUSBoost');

YPred = predict(RUSboostmodelL,testingFV);

accuracy = mean(YPred == testSet.Labels)
confusionchart(YTest,YPred,'RowSummary','row-normalized','ColumnSummary','column-normalized');
title("PCA Fusion using RUSBoost");
%%

for i=1:length(YPred)
 if (YPred(i)=='ALL')
     YPred_num(i)=0;
 elseif(YPred(i)=='AML')
     YPred_num(i)=1;
 elseif(YPred(i)=='MM')
     YPred_num(i)=2;
 end   
end
%%
[c_matrixp,Result]= confusion.getMatrix(YTest_num,YPred_num);

disp('Getting Values')
Accuracy=Result.Accuracy
Error=Result.Error
Sensitivity=Result.Sensitivity
Specificity=Result.Specificity
Precision=Result.Precision
FalsePositiveRate=Result.FalsePositiveRate
F1_score=Result.F1_score
MatthewsCorrelationCoefficient=Result.MatthewsCorrelationCoefficient
Kappa=Result.Kappa