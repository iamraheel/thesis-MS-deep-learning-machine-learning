
srcFiles = dir('C:\Users\uogpk\Downloads\finalDataset_BloodCancer\MM\*.bmp');  % the folder in which ur images exists
nameiter=0;
for i = 1 : length(srcFiles)
filename = strcat('C:\Users\uogpk\Downloads\finalDataset_BloodCancer\MM\',srcFiles(i).name);

I = imread(filename);

pout=rgb2gray(I);
pout_imadjust = imadjust(pout,[0.3 0.5]);
pout_adapthisteq = adapthisteq(pout_imadjust);
% figure
% subplot(1,2,1)
% imhist(I)
% title('Histogram of Original')
% subplot(1,2,2)
% imhist(pout_adapthisteq)
% title('Histogram of Aqaptive Equalization');

%figure,imshow(pout_imadjust)

% pout_histeq = histeq(pout);
% pout_adapthisteq = adapthisteq(pout);
% %
% montage({pout,pout_imadjust,pout_histeq,pout_adapthisteq},'Size',[1 4])
% title("Original Image and Enhanced Images using imadjust, histeq, and adapthisteq")

poutnew=pout.*pout_adapthisteq;
%figure,imshowpair(I,poutnew,'montage')

bw=imbinarize(poutnew);
bw_select=bwareafilt(imcomplement(bw),[1000 1000000]);
%figure,imshowpair(I,bw_select,'montage')
 [L, num1] = bwlabel(bw_select);
for k1 = 1 : num1
    
   Blob = ismember(L, k1);
   newww=I.*uint8(Blob);
    %figure,imshow(newww)
    k=imresize(newww,[400 400]);
    nameiter=nameiter+1;
    imwrite(k, sprintf('MM_%d.jpg',nameiter) );
    %newfilename=strcat('C:\Users\uogpk\Downloads\finalDataset_BloodCancer\ALL_Segmented\',srcFiles(i).name);
    %imwrite(k,newfilename,'jpg');
   
end

end