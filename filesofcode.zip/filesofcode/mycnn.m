
imageFolder = fullfile('C:\Users\uogpk\Downloads\finalDataset_BloodCancer\','Segmented');

imds = imageDatastore(imageFolder, ...
    'IncludeSubfolders',true, ...
    'LabelSource','foldernames');
%%
[trainingSet, testSet] = splitEachLabel(imds, 0.7, 'randomize');

%%
figure
numImages = 900;
perm = randperm(numImages,20);
for i = 1:20
    subplot(4,5,i);
    imshow(imds.Files{perm(i)});
    drawnow;
end
%%
imageSize=[200 200 3];
augmentedTrainingSet = augmentedImageDatastore(imageSize, trainingSet, 'ColorPreprocessing', 'gray2rgb');
augmentedTestSet = augmentedImageDatastore(imageSize, testSet, 'ColorPreprocessing', 'gray2rgb');
%%
layers = [
    imageInputLayer([200 200 3])
    
    convolution2dLayer(3,96,'Padding','same')
    batchNormalizationLayer
    reluLayer    
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(3,48,'Padding','same')
    batchNormalizationLayer
    reluLayer   
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(3,24,'Padding','same')
    batchNormalizationLayer
    reluLayer  
    maxPooling2dLayer(2,'Stride',2)

    
    convolution2dLayer(3,12,'Padding','same')
    batchNormalizationLayer
    reluLayer   
    
    fullyConnectedLayer(3)
    softmaxLayer %activation function%
    classificationLayer];
%
options = trainingOptions('sgdm', ...
    'MaxEpochs',500,...
    'InitialLearnRate',1e-4, ...
    'Verbose',false, ...
    'Plots','training-progress','ValidationData',{augmentedTestSet,testSet.Labels});
%%
net = trainNetwork(augmentedTrainingSet,layers,options);

%%
YPred = classify(net,augmentedTestSet);
YTest = testSet.Labels;
%Calculate the accuracy. The accuracy is the ratio of the number of true labels in the test data matching the classifications from classify to the number of images in the test data.

accuracy = sum(YPred == YTest)/numel(YTest)