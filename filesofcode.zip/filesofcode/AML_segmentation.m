

srcFiles = dir('C:\Users\uogpk\Downloads\finalDataset_BloodCancer\AML\*.tiff');  % the folder in which ur images exists

for i = 1 : length(srcFiles)
filename = strcat('C:\Users\uogpk\Downloads\finalDataset_BloodCancer\AML\',srcFiles(i).name);

I = imread(filename);
%I=squeeze(I);
pout=rgb2gray(I(:,:,1:3));
pout_imadjust = imadjust(pout,[0.3 0.5]);
pout_adapthisteq = adapthisteq(pout_imadjust);
% figure
% subplot(1,2,1)
% imhist(I(:,:,1:3))
% title('Histogram of Original')
% subplot(1,2,2)
% imhist(pout_adapthisteq)
% title('Histogram of Aqaptive Equalization');

poutnew=pout.*pout_adapthisteq;

bw=imbinarize(poutnew);
bw_select=bwareafilt(imcomplement(bw),[100 1000000]);

newww=I(:,:,1:3).*uint8(bw_select);
%figure,imshowpair(I(:,:,1:3),newww,'montage')


k=imresize(newww,[400 400]);
newfilename=strcat('C:\Users\uogpk\Downloads\finalDataset_BloodCancer\AML_segmented\',srcFiles(i).name);
imwrite(k,newfilename,'jpg');
end
